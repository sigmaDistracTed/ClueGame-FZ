package clueGame;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import javax.swing.plaf.basic.BasicButtonListener;
import javax.swing.border.TitledBorder;

public class KnownCardsPanel extends JPanel {
	private KnownCardsPanel gui;

	private Player huP;

	private JPanel peoplePanel;
	private JPanel roomsPanel;
	private JPanel weaponsPanel;

	private JPanel peopleHandPanel;
	private JPanel peopleSeenPanel;
	
	private JPanel roomsHandPanel;
	private JPanel roomsSeenPanel;

	private JPanel weaponsHandPanel;
	private JPanel weaponsSeenPanel;
	
	public KnownCardsPanel() {
		gui = this;
		setLayout(new GridLayout(3, 1));
		setBorder(BorderFactory.createTitledBorder("Known Cards"));
		((TitledBorder) getBorder()).setTitleFont(getFont().deriveFont(Font.BOLD));
		((TitledBorder) getBorder()).setTitleJustification(TitledBorder.CENTER);

		// Find the human player
		for (Player player : Board.getInstance().getPlayers()) {
			if (player instanceof HumanPlayer) {
				huP = player;
				break;
			}
		}

		// Create category panels
		peoplePanel = new JPanel(new GridBagLayout());
		roomsPanel = new JPanel(new GridBagLayout());
		weaponsPanel = new JPanel(new GridBagLayout());

		TitledBorder peopleBorder = BorderFactory.createTitledBorder("People");
		peopleBorder.setTitleFont(peoplePanel.getFont().deriveFont(Font.BOLD));
		peoplePanel.setBorder(peopleBorder);
		TitledBorder roomsBorder = BorderFactory.createTitledBorder("Rooms");
		roomsBorder.setTitleFont(roomsPanel.getFont().deriveFont(Font.BOLD));
		roomsPanel.setBorder(roomsBorder);
		TitledBorder weaponsBorder = BorderFactory.createTitledBorder("Weapons");
		weaponsBorder.setTitleFont(weaponsPanel.getFont().deriveFont(Font.BOLD));
		weaponsPanel.setBorder(weaponsBorder);

		// Create card containers
		peopleHandPanel = new JPanel(new GridLayout(0, 1, 0, 1));
		peopleSeenPanel = new JPanel(new GridLayout(0, 1, 0, 2));
		roomsHandPanel = new JPanel(new GridLayout(0, 1, 0, 1));
		roomsSeenPanel = new JPanel(new GridLayout(0, 1, 0, 2));
		weaponsHandPanel = new JPanel(new GridLayout(0, 1, 0, 1));
		weaponsSeenPanel = new JPanel(new GridLayout(0, 1, 0, 2));

		// Fill hand containers
		for (Card card : huP.getHand()) {
			JTextField field = createCardField(card.getCardName());
			
			switch (card.getCardType()) {
				case PERSON: peopleHandPanel.add(field); break;
				case ROOM: roomsHandPanel.add(field); break;
				case WEAPON: weaponsHandPanel.add(field); break;
			}

			field.setBackground(huP.getColor());
		}

		if (peopleHandPanel.getComponentCount() == 0) {
			peopleHandPanel.add(createCardField("None"));
		}
		if (roomsHandPanel.getComponentCount() == 0) {
			roomsHandPanel.add(createCardField("None"));
		}
		if (weaponsHandPanel.getComponentCount() == 0) {
			weaponsHandPanel.add(createCardField("None"));
		}

		// Constraints
		GridBagConstraints c = new GridBagConstraints();
		c.gridx = 0;
		c.weightx = 1;
		c.weighty = 1;
		c.fill = GridBagConstraints.BOTH;
		c.insets = new Insets(2, 4, 2, 4);

		JLabel handLabel;
		JLabel seenLabel;

		// People
		c.gridy = 0;
		handLabel = new JLabel("In Hand:");
		handLabel.setFont(handLabel.getFont().deriveFont(Font.BOLD));
		peoplePanel.add(handLabel, c);

		c.gridy = 1;
		peoplePanel.add(peopleHandPanel, c);

		c.gridy = 2;
		seenLabel = new JLabel("Seen:");
		seenLabel.setFont(seenLabel.getFont().deriveFont(Font.BOLD));
		peoplePanel.add(seenLabel, c);

		c.gridy = 3;
		peoplePanel.add(peopleSeenPanel, c);

		// Rooms
		c.gridy = 0;
		handLabel = new JLabel("In Hand:");
		handLabel.setFont(handLabel.getFont().deriveFont(Font.BOLD));
		roomsPanel.add(handLabel, c);

		c.gridy = 1;
		roomsPanel.add(roomsHandPanel, c);

		c.gridy = 2;
		seenLabel = new JLabel("Seen:");
		seenLabel.setFont(seenLabel.getFont().deriveFont(Font.BOLD));
		roomsPanel.add(seenLabel, c);

		c.gridy = 3;
		roomsPanel.add(roomsSeenPanel, c);

		// Weapons
		c.gridy = 0;
		handLabel = new JLabel("In Hand:");
		handLabel.setFont(handLabel.getFont().deriveFont(Font.BOLD));
		weaponsPanel.add(handLabel, c);

		c.gridy = 1;
		weaponsPanel.add(weaponsHandPanel, c);

		c.gridy = 2;
		seenLabel = new JLabel("Seen:");
		seenLabel.setFont(seenLabel.getFont().deriveFont(Font.BOLD));
		weaponsPanel.add(seenLabel, c);

		c.gridy = 3;
		weaponsPanel.add(weaponsSeenPanel, c);

		add(peoplePanel);
		add(roomsPanel);
		add(weaponsPanel);

		refreshCardsGUI();

		// Connect panel to the human player
    	((HumanPlayer) huP).setKnownCardsPanel(this);
	}

	// Will update the seen panels whenever a new card is seen
	public void refreshCardsGUI() {
		peopleSeenPanel.removeAll();
		weaponsSeenPanel.removeAll();
		roomsSeenPanel.removeAll();

		for (Card card : huP.getSeen()) {
			JTextField field = createCardField(card.getCardName());

			for (Player player : Board.getInstance().getPlayers()) {
				for (Card heldCard : player.getHand()) {
					if (heldCard.getCardType() == card.getCardType() && heldCard.getCardName().equals(card.getCardName())) {
						Color color = player.getColor();
						field.setBackground(color);
						break;
					}
				}
			}
			switch(card.getCardType()) {
				case PERSON: peopleSeenPanel.add(field); break;
				case ROOM: roomsSeenPanel.add(field); break;
				case WEAPON: weaponsSeenPanel.add(field); break;
			}
		}

		if (peopleSeenPanel.getComponentCount() == 0) {
			peopleSeenPanel.add(createCardField("None"));
		}
		if (roomsSeenPanel.getComponentCount() == 0) {
			roomsSeenPanel.add(createCardField("None"));
		}
		if (weaponsSeenPanel.getComponentCount() == 0) {
			weaponsSeenPanel.add(createCardField("None"));
		}

		revalidate();
		repaint();
	}

	private JTextField createCardField(String text) {
		JTextField field = new JTextField(text);
		field.setEditable(false);
		field.setBorder(BorderFactory.createCompoundBorder(
			BorderFactory.createLineBorder(Color.GRAY),
			BorderFactory.createEmptyBorder(4, 4, 4, 4)
		));
		return field;
	}
	
	private class ButtonListener implements ActionListener {
        @Override 
        public void actionPerformed(ActionEvent e) {
        }
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(KnownCardsPanel::showPreview);
	}

	private static void showPreview() {
		Board board = Board.getInstance();
		board.setConfigFiles("ClueLayout.csv", "ClueSetup.txt");
		board.initialize();

		KnownCardsPanel panel = new KnownCardsPanel();  // create the panel
		JFrame frame = new JFrame("Clue Controls");  // create the frame 
		frame.setContentPane(panel); // put the panel in the frame
		frame.setSize(250, 1000);;  // size the frame
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // allow it to close
		frame.setVisible(true); // make it visible

		// Test filling in seen containers
		for (Card card : board.getCards()) {
			if (!panel.huP.getHand().contains(card)) {
				panel.huP.updateSeen(card);
			}
		}
	}

}
